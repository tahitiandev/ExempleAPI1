﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace geststock.Controllers.Models
{
    public class Hellos
    {
        public int? Id { get; set; }
        public string Libelle { get; set; }
    }
}
