﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace geststock.Controllers.Models
{
    public class Pieces
    {
        public int? IdPiece { get; set; }
        public string Code { get; set; }
        public string Libelle { get; set; }
    }
}
