import { Component, OnInit } from '@angular/core';
import { TestService } from '../test.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detail-test',
  templateUrl: './detail-test.component.html',
  styleUrls: ['./detail-test.component.scss']
})
export class DetailTestComponent implements OnInit {

  constructor(private service : TestService, private route: ActivatedRoute) { }

  name : string;
  first : string;

  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    this.name = this.service.getDetail(+id).name;
    this.first = this.service.getDetail(+id).first;
  }

}
