import { Component, OnInit } from '@angular/core';
import { TestService } from '../test.service';

@Component({
  selector: 'app-view-test',
  templateUrl: './view-test.component.html',
  styleUrls: ['./view-test.component.scss']
})
export class ViewTestComponent implements OnInit {

  constructor(private service : TestService) { }

  tests : any[];

  ngOnInit() {
    this.tests = this.service.tests;
  }

}
