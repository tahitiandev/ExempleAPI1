import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  constructor() { }

  tests = [
    {
      id : 1,
      name : "HEITAA",
      first : "Gilles"
    },
    {
      id : 2,
      name : "test",
      first : "retest"
    }
  ];

  getDetail(id : number){
    const test = this.tests.find(
      (s) => {
        return s.id === id;
      }
    );
    return test;
  }


}
