import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { helloModel } from '../models/hellos.model';

@Injectable({
  providedIn: 'root'
})
export class HelloService {

  constructor(private http : HttpClient) { }

  getData(){
    return this.http.get<helloModel[]>("http://localhost:5000/api/hellos");
  }

}
