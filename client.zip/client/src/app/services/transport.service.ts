import { Injectable } from '@angular/core';
import { UtilyService } from './utily.service';
import { HttpClient } from '@angular/common/http';
import { transportModel } from '../models/transport.model';

@Injectable({
  providedIn: 'root'
})
export class TransportService {

  constructor(private s : UtilyService,
              private http : HttpClient) { }

  transport : transportModel[];

  getFromServer(){
    return this.http.get<transportModel[]>(this.s.UrlApi + "/transport");
  }

  post(data : transportModel){
    return this.http.post<transportModel[]>("http://localhost:5000/api/transport",data);
  }

  update(data : transportModel){
    return this.http.put("http://localhost:5000/api/transport", data);
  }

}
