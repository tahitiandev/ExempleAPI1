import { Injectable } from '@angular/core';
import { UtilyService } from './utily.service';
import { HttpClient } from '@angular/common/http';
import { testModel } from '../models/test.model';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  constructor(private s : UtilyService,
              private http : HttpClient) { }

  getData(){
    return this.http.get<testModel[]>('http://localhost:5000/api/tests');
  }






}
