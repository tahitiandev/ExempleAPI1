import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UtilyService } from './utily.service';
import { pieceModel } from '../models/piece.model';
import { TestBed } from '@angular/core/testing';

@Injectable({
  providedIn: 'root'
})
export class PieceService {

  constructor(private http : HttpClient,
              private s : UtilyService) { }

    piece : pieceModel[];

    rIdPiece : number;
    rCode : string;
    rLibelle : string;

    getServer(){
      return this.http.get<pieceModel[]>(this.s.UrlApi + "/Piece");
    }

    PostPieceModel(data : pieceModel){
      return this.http.post<pieceModel[]>("http://localhost:5000/api/Piece", data);
    }
    
    AfficheResult(){
      return this.getServer().subscribe(s => this.piece = s);
    }
    GetDetail(se : number){

      const result = new pieceModel(
        this.rIdPiece,
        this.rCode,
        this.rLibelle
      );
    }

}
