import { Injectable } from '@angular/core';
import { categorieModel } from '../models/categorie.model';
import { UtilyService } from './utily.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CategorieService {

  constructor(private s : UtilyService,
              private http : HttpClient) { }

  categories : categorieModel[];

  getFromServer(){
    return this.http.get<categorieModel[]>(this.s.UrlApi + "/categorie");
  }

  PostCategorie(categorie : categorieModel){
    return this.http.post<categorieModel[]>("http://localhost:5000/api/categorie", categorie);
  }

  getDetail(id : number){
    const cat = this.categories.find(
      (s) => {
        return s.id === id;
      }
    );
    return cat;
  }


}
