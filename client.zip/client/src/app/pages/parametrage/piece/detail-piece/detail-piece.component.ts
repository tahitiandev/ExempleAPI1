import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-piece',
  templateUrl: './detail-piece.component.html',
  styleUrls: ['./detail-piece.component.scss']
})
export class DetailPieceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
