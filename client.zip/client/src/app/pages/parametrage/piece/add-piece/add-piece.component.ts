import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { PieceService } from 'src/app/services/piece.service';
import { pieceModel } from 'src/app/models/piece.model';

@Component({
  selector: 'app-add-piece',
  templateUrl: './add-piece.component.html',
  styleUrls: ['./add-piece.component.scss']
})
export class AddPieceComponent implements OnInit {

  constructor(private service : PieceService,
              private formbuilder: FormBuilder) { }

  formgroup :  FormGroup;

  ngOnInit() {
    this.init();
  }

  init(){
    this.formgroup = this.formbuilder.group({
      IdPiece : '',
      Code : '',
      Libelle : ''
    });
  }

  onsubmit(){
    const POST = this.formgroup.value;
    const data = new pieceModel(
      POST['IdPiece'],
      POST['Code'],
      POST['Libelle']
    )

    this.service.PostPieceModel(data).subscribe(
      res => {
        console.log('données envoyées');
      },
      err => {
        console.log("erreur : non envoyée");
      }
    );

  }

}
