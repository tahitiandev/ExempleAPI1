import { Component, OnInit } from '@angular/core';
import { PieceService } from 'src/app/services/piece.service';
import { pieceModel } from 'src/app/models/piece.model';

@Component({
  selector: 'app-view-piece',
  templateUrl: './view-piece.component.html',
  styleUrls: ['./view-piece.component.scss']
})
export class ViewPieceComponent implements OnInit {

  constructor(private service : PieceService) { }

  pieces : pieceModel[];

  ngOnInit() {
    this.service.getServer()
                .subscribe(t => this.pieces = t);
  }

}
