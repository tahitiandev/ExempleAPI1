import { Component, OnInit } from '@angular/core';
import { TransportService } from 'src/app/services/transport.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { transportModel } from 'src/app/models/transport.model';

@Component({
  selector: 'app-update-transport',
  templateUrl: './update-transport.component.html',
  styleUrls: ['./update-transport.component.scss']
})
export class UpdateTransportComponent implements OnInit {

  constructor(private service : TransportService,
              private formbuilder :  FormBuilder) { }

  formgroup : FormGroup;

  ngOnInit() {
    this.init();
  }

  init(){
    this.formgroup = this.formbuilder.group({
      Code : '',
      Libelle : '',
      Voix : ''
    });
  }

  onPut(){
    const put = this.formgroup.value;
    const data = new transportModel(
      put['Code'],
      put['Libelle'],
      put['Voix']
    );
    this.service.update(data);
  }



}
