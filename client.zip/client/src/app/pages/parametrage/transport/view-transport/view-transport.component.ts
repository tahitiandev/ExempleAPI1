import { Component, OnInit } from '@angular/core';
import { TransportService } from 'src/app/services/transport.service';
import { transportModel } from 'src/app/models/transport.model';

@Component({
  selector: 'app-view-transport',
  templateUrl: './view-transport.component.html',
  styleUrls: ['./view-transport.component.scss']
})
export class ViewTransportComponent implements OnInit {

  constructor(private service : TransportService) { }

  transports : transportModel[];

  ngOnInit() {
    this.service.getFromServer()
                .subscribe(s => this.transports = s);
  }

}
