import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { TransportService } from 'src/app/services/transport.service';
import { transportModel } from 'src/app/models/transport.model';

@Component({
  selector: 'app-add-transport',
  templateUrl: './add-transport.component.html',
  styleUrls: ['./add-transport.component.scss']
})
export class AddTransportComponent implements OnInit {

  constructor(private service : TransportService,
              private formbuilder : FormBuilder) { }

  formgroup : FormGroup;

  ngOnInit() {
    this.init();
  }

  init(){
    this.formgroup = this.formbuilder.group({
      Code : '',
      Libelle : '',
      Voix : ''
    })
  }

  onSubmit(){
    const post = this.formgroup.value;
    const data = new transportModel(
      post['Code'],
      post['Libelle'],
      post['Voix']
    );
    
    this.service.post(data).subscribe(
      res => {
        console.log("success");
      },
      err => {
        console.log(err);
      }
    )
    
  }


}
