import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CategorieService } from 'src/app/services/categorie.service';
import { categorieModel } from 'src/app/models/categorie.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-categorie',
  templateUrl: './add-categorie.component.html',
  styleUrls: ['./add-categorie.component.scss']
})
export class AddCategorieComponent implements OnInit {

  constructor(private frombuilder : FormBuilder,
              private service : CategorieService,
              private nav : Router) { }

  formgroup : FormGroup;


  ngOnInit() {
    this.init();
  }

  init(){
    this.formgroup = this.frombuilder.group({
      id : '',
      libelle : '',
      description : ''
    });
  }

  onSubmit(){
    const data = this.formgroup.value;
    const alldata = new categorieModel(
      data['id'],
      data['libelle'],
      data['description']
    );

    this.service.PostCategorie(alldata).subscribe(
      res => {
        console.log("sucess");
      },
      err => {
        console.log("error : " + err);
      }
    );


  }


}
