import { Component, OnInit } from '@angular/core';
import { CategorieService } from 'src/app/services/categorie.service';
import { ActivatedRoute } from '@angular/router';
import { categorieModel } from 'src/app/models/categorie.model';

@Component({
  selector: 'app-detail-categorie',
  templateUrl: './detail-categorie.component.html',
  styleUrls: ['./detail-categorie.component.scss']
})
export class DetailCategorieComponent implements OnInit {

  categoriedetail : categorieModel[];

  myid : number;

  constructor(private service : CategorieService,
              private route : ActivatedRoute) { }

  ngOnInit() {
    const myid = this.route.snapshot.params['id'];

    this.service.getFromServer().subscribe(t => this.categoriedetail = t);

    
  }

}
