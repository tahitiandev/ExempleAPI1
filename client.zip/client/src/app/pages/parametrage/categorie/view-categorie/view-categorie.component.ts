import { Component, OnInit } from '@angular/core';
import { CategorieService } from 'src/app/services/categorie.service';
import { categorieModel } from 'src/app/models/categorie.model';

@Component({
  selector: 'app-view-categorie',
  templateUrl: './view-categorie.component.html',
  styleUrls: ['./view-categorie.component.scss']
})
export class ViewCategorieComponent implements OnInit {

  constructor(private service : CategorieService) { }

  categories : categorieModel[];

  ngOnInit() {
    this.service.getFromServer().subscribe(t => this.categories = t);
  }

}
