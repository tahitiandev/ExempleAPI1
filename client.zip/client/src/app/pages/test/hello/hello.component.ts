import { Component, OnInit } from '@angular/core';
import { helloModel } from 'src/app/models/hellos.model';
import { HelloService } from 'src/app/services/hello.service';

@Component({
  selector: 'app-hello',
  templateUrl: './hello.component.html',
  styleUrls: ['./hello.component.scss']
})
export class HelloComponent implements OnInit {

  constructor(private service : HelloService) { }

  hello : helloModel[];

  ngOnInit() {
    this.service.getData().subscribe(t => this.hello = t);
  }

}
