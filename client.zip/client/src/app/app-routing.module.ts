import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewPieceComponent } from './pages/parametrage/piece/view-piece/view-piece.component';
import { ViewTransportComponent } from './pages/parametrage/transport/view-transport/view-transport.component';
import { ViewCategorieComponent } from './pages/parametrage/categorie/view-categorie/view-categorie.component';
import { AddCategorieComponent } from './pages/parametrage/categorie/add-categorie/add-categorie.component';
import { DetailCategorieComponent } from './pages/parametrage/categorie/detail-categorie/detail-categorie.component';
import { DetailTestComponent } from './test/detail-test/detail-test.component';
import { ViewTestComponent } from './test/view-test/view-test.component';

const routes: Routes = [
  {path : 'view-piece', component : ViewPieceComponent},
  {path : 'view-transport', component : ViewTransportComponent},
  {path : 'view-categorie', component : ViewCategorieComponent},
  {path : 'view-test', component : ViewTestComponent},
  {path : 'view-test/:id', component : DetailTestComponent},

  {path : 'add-categorie', component : AddCategorieComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
