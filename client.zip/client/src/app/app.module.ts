import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewPieceComponent } from './pages/parametrage/piece/view-piece/view-piece.component';
import { ViewCategorieComponent } from './pages/parametrage/categorie/view-categorie/view-categorie.component';
import { ViewTransportComponent } from './pages/parametrage/transport/view-transport/view-transport.component';
import { AddCategorieComponent } from './pages/parametrage/categorie/add-categorie/add-categorie.component';
import { AddPieceComponent } from './pages/parametrage/piece/add-piece/add-piece.component';
import { AddTransportComponent } from './pages/parametrage/transport/add-transport/add-transport.component';
import { UpdateTransportComponent } from './pages/parametrage/transport/update-transport/update-transport.component';
import { DetailCategorieComponent } from './pages/parametrage/categorie/detail-categorie/detail-categorie.component';
import { ViewTestComponent } from './test/view-test/view-test.component';
import { DetailTestComponent } from './test/detail-test/detail-test.component';
import { DetailPieceComponent } from './pages/parametrage/piece/detail-piece/detail-piece.component';
import { HelloComponent } from './pages/test/hello/hello.component';

@NgModule({
  declarations: [
    AppComponent,
    ViewPieceComponent,
    ViewCategorieComponent,
    ViewTransportComponent,
    AddCategorieComponent,
    AddPieceComponent,
    AddTransportComponent,
    UpdateTransportComponent,
    DetailCategorieComponent,
    ViewTestComponent,
    DetailTestComponent,
    DetailPieceComponent,
    HelloComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
