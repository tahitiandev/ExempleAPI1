export class transportModel{
    constructor(
        public Code : string,
        public Libelle : string,
        public Voix : string
    ){}
}