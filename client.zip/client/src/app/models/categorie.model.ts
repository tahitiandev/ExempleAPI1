export class categorieModel{
    constructor(
        public id : number,
        public libelle : string,
        public description : string
        ){}
}