export class helloModel{
    constructor(
        public id : number,
        public libelle : string
    ){}
}