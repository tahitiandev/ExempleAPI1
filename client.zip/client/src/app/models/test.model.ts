export class testModel{
    constructor(
        public id : number,
        public intitule : string
    ){}
}