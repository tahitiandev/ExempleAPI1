export class pieceModel{
    constructor(
        public IdPiece : number,
        public Code : string,
        public Libelle : string
    ){}
}